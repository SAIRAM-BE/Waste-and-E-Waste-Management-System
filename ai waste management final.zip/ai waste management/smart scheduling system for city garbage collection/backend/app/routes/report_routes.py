from fastapi import APIRouter, UploadFile, File, Form
import json, os
from ultralytics import YOLO

router = APIRouter()
model = YOLO("best.pt")

os.makedirs("uploads", exist_ok=True)

# -------------------------
# 🧹 COMPLAINT (AI VERIFY)
# -------------------------
@router.post("/report")
async def report(
    lat: float = Form(...),
    lng: float = Form(...),
    landmark: str = Form(...),
    contact: str = Form(...),
    file: UploadFile = File(...)
):
    filepath = f"uploads/{file.filename}"

    with open(filepath, "wb") as f:
        f.write(await file.read())

    results = model(filepath)

    garbage_detected = False
    for r in results:
        if len(r.boxes) > 0:
            garbage_detected = True

    try:
        with open("data/reports.json", "r") as f:
            reports = json.load(f)
    except:
        reports = []

    reports.append({
        "lat": lat,
        "lng": lng,
        "type": "complaint",
        "landmark": landmark,
        "contact": contact,
        "verified": garbage_detected,
        "image": filepath
    })

    with open("data/reports.json", "w") as f:
        json.dump(reports, f)

    return {"verified": garbage_detected}

# -------------------------
# ♻️ E-WASTE (NO AI)
# -------------------------
@router.post("/ewaste")
async def ewaste(
    lat: float = Form(...),
    lng: float = Form(...),
    landmark: str = Form(...),
    contact: str = Form(...)
):
    try:
        with open("data/user_tasks.json", "r") as f:
            tasks = json.load(f)
    except:
        tasks = []

    tasks.append({
        "lat": lat,
        "lng": lng,
        "type": "ewaste",
        "landmark": landmark,
        "contact": contact
    })

    with open("data/user_tasks.json", "w") as f:
        json.dump(tasks, f)

    return {"message": "E-waste added"}
