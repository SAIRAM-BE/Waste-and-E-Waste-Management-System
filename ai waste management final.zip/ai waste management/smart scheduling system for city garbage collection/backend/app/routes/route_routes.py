from fastapi import APIRouter
from app.services.task_service import generate_tasks
from app.services.assignment_service import assign_tasks
from app.services.detection_service import run_detection

router = APIRouter()


# 🧠 Smart route (Nearest Neighbor)
def optimize_route(points):

    if not points:
        return []

    route = [points[0]]
    remaining = points[1:]

    while remaining:
        last = route[-1]

        nearest = min(
            remaining,
            key=lambda p: (p["lat"] - last["lat"])**2 + (p["lng"] - last["lng"])**2
        )

        route.append(nearest)
        remaining.remove(nearest)

    return route


@router.get("/route")
def get_route():

    run_detection()
    tasks = generate_tasks()
    assignments = assign_tasks(tasks)

    optimized_routes = {}

    for worker_id, worker_tasks in assignments.items():

        # ✅ Keep only valid tasks
        worker_tasks = [t for t in worker_tasks if "type" in t]

        if not worker_tasks:
            continue

        print(f"Worker {worker_id} tasks:", worker_tasks)

        # 🧠 Optimize route
        optimized = optimize_route(worker_tasks)

        # 🏢 Office (Start)
        office = {
            "lat": 9.9001,
            "lng": 78.11691,
            "type": "office",
            "name": "Corporation Office"
        }

        # 🗑 Dump Yard
        dump = {
            "lat": 9.87152,
            "lng": 78.10602,
            "type": "dump",
            "name": "Dump Yard"
        }

        # 🔥 Detect task types
        task_types = set(t["type"] for t in worker_tasks)

        # ♻️ EWASTE → return to office
        if task_types == {"ewaste"}:
            full_route = [office] + optimized + [office]

        # 🧹 Complaint → go to dump
        elif "complaint" in task_types:
            full_route = [office] + optimized + [dump]

        # 🚛 Overflow → go to dump
        elif "overflow" in task_types:
            full_route = [office] + optimized + [dump]

        # fallback
        else:
            full_route = [office] + optimized + [dump]

        optimized_routes[str(worker_id)] = full_route

    return {"routes": optimized_routes}

@router.get("/admin_full")
def admin_full():

    tasks = generate_tasks()
    workers = assign_tasks(tasks)

    overflow = [t for t in tasks if t["type"] == "overflow"]
    complaints = [t for t in tasks if t["type"] == "complaint"]
    ewaste = [t for t in tasks if t["type"] == "ewaste"]

    return {
        "stats": {
            "overflow": len(overflow),
            "complaints": len(complaints),
            "ewaste": len(ewaste),
            "workers": len(workers)
        },
        "tasks": tasks
    }
