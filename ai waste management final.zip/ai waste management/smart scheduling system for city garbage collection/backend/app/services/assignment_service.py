import json
from collections import defaultdict
import math

# 📍 Distance formula
def distance(a, b):
    return math.sqrt((a["lat"] - b["lat"])**2 + (a["lng"] - b["lng"])**2)

# 📍 Smart route ordering (Nearest Neighbor)
def optimize_route(points):

    if not points:
        return []

    route = []
    current = points[0]   # start point
    remaining = points[1:]

    route.append(current)

    while remaining:
        nearest = min(remaining, key=lambda x: distance(current, x))
        route.append(nearest)
        remaining.remove(nearest)
        current = nearest

    return route


def load_workers():
    try:
        with open("data/workers.json") as f:
            return json.load(f)
    except:
        return []


def assign_tasks(tasks):

    workers = load_workers()
    assignments = defaultdict(list)

    truck_workers = [w for w in workers if w["role"] == "truck"]
    cleaners = [w for w in workers if w["role"] == "cleaner"]

    # 📍 Define fixed points
    OFFICE = {"lat": 9.9001, "lng": 78.11691}
    DUMP_YARD = {"lat": 9.87152, "lng": 78.10602}

    # ---------------------------
    # 🚛 TRUCK ROUTE (SMART)
    # ---------------------------
    overflow_tasks = [t for t in tasks if t["type"] == "overflow"]

    if overflow_tasks:
        route = [OFFICE] + optimize_route(overflow_tasks) + [DUMP_YARD]

        for truck in truck_workers:
            assignments[str(truck["id"])] = route

    # ---------------------------
    # 🧹 CLEANERS
    # ---------------------------
    # ---------------------------
    # 🧹 CLEANERS (complaint + ewaste)
    # ---------------------------
    cleaner_tasks = [t for t in tasks if t["type"] in ["complaint", "ewaste"]]

    clean_index = 0

    for task in cleaner_tasks:

        worker = cleaners[clean_index % len(cleaners)]

        # 🔥 FIX HERE
        if task["type"] == "ewaste":
            route = [OFFICE, task, OFFICE]   # ✅ return to office
        else:
            route = [OFFICE, task, DUMP_YARD]  # complaint → dump

        assignments[str(worker["id"])] = route

        clean_index += 1

    return assignments
