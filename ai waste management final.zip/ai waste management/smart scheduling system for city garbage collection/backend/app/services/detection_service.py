import os
import json
from ultralytics import YOLO

model = YOLO("best.pt")

IMAGE_FOLDER = "data/images"
BINS_FILE = "data/bins.json"
REPORT_FILE = "data/reports.json"


def run_detection():

    # Load bins mapping
    with open(BINS_FILE, "r") as f:
        bins = json.load(f)

    # Load old reports
    try:
        with open(REPORT_FILE, "r") as f:
            reports = json.load(f)
    except:
        reports = []

    # 🔥 Remove old overflow only
    reports = [r for r in reports if r.get("type") != "overflow"]

    for b in bins:

        img_path = os.path.join(IMAGE_FOLDER, b["image"])

        if not os.path.exists(img_path):
            continue

        print(f"Processing {b['image']}")

        os.makedirs("data/output", exist_ok=True) #
        results = model(img_path)
        output_filename = b["image"]   # img1.jpg

        output_path = os.path.join("data/output", output_filename)

        results[0].save(filename=output_path)

        garbage_detected = False

        for r in results:
            if len(r.boxes) > 0:
                garbage_detected = True

        # ✅ Save ONLY if overflow detected
        if garbage_detected:
            reports.append({
                "lat": b["lat"],
                "lng": b["lng"],
                "type": "overflow",
                "verified": True,
                "bin_id": b["id"],
                "landmark": b["landmark"],
                "image": output_filename
            })

    with open(REPORT_FILE, "w") as f:
        json.dump(reports, f)

    print("✅ Detection + bin mapping completed")
