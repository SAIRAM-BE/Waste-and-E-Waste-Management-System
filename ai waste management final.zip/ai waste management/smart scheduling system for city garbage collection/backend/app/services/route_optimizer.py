import math

# 📍 Distance function
def distance(a, b):
    return math.sqrt((a["lat"] - b["lat"])**2 + (a["lng"] - b["lng"])**2)


# 🧠 Nearest Neighbor (simple TSP)
def optimize_route(start, tasks):

    if not tasks:
        return []

    unvisited = tasks.copy()
    route = []
    current = start

    while unvisited:
        nearest = min(unvisited, key=lambda x: distance(current, x))
        route.append(nearest)
        current = nearest
        unvisited.remove(nearest)

    return route
