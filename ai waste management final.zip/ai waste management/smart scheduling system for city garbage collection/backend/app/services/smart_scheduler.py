from ortools.constraint_solver import pywrapcp, routing_enums_pb2
import math

def distance(p1, p2):
    return int(math.sqrt(
        (p1["lat"] - p2["lat"])**2 +
        (p1["lng"] - p2["lng"])**2
    ) * 10000)

def solve_vrp(tasks):

    if len(tasks) == 0:
        return []

    dist_matrix = []
    for t1 in tasks:
        row = []
        for t2 in tasks:
            row.append(distance(t1, t2))
        dist_matrix.append(row)

    manager = pywrapcp.RoutingIndexManager(len(dist_matrix), 2, 0)
    routing = pywrapcp.RoutingModel(manager)

    def dist_callback(from_index, to_index):
        return dist_matrix[
            manager.IndexToNode(from_index)
        ][
            manager.IndexToNode(to_index)
        ]

    transit_callback_index = routing.RegisterTransitCallback(dist_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    )

    solution = routing.SolveWithParameters(search_parameters)

    routes = []

    if solution:
        for vehicle_id in range(2):
            index = routing.Start(vehicle_id)
            route = []

            while not routing.IsEnd(index):
                node = manager.IndexToNode(index)
                route.append(tasks[node])
                index = solution.Value(routing.NextVar(index))

            routes.append(route)

    return routes
