import json

def load_reports():
    try:
        with open("data/reports.json") as f:
            return json.load(f)
    except:
        return []

def load_user_tasks():
    try:
        with open("data/user_tasks.json") as f:
            return json.load(f)
    except:
        return []

def generate_tasks():

    reports = load_reports()
    user_tasks = load_user_tasks()

    tasks = []

    # 🚛 Overflow (ONLY from detection)
    for r in reports:
        if r.get("type") == "overflow":
            tasks.append(r)

    # 🧹 Complaint (NOT verified)
    for r in reports:
        if r.get("type") == "complaint" and r.get("verified"):
            tasks.append({
                "lat": r["lat"],
                "lng": r["lng"],
                "type": "complaint",
                "landmark": r.get("landmark"),
                "contact": r.get("contact")
            })

    # ♻️ Ewaste
    for t in user_tasks:
        if t.get("type") == "ewaste":
            tasks.append(t)

    return tasks
